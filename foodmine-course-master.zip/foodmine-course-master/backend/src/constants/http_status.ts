export const HTTP_BAD_REQUEST = 400;
export const HTTP_UNAUTHORIZED = 401;